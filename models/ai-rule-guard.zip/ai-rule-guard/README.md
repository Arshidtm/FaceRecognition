# AI Rule Guard – VS Code Extension with Node + Mistral AI

> **Hackathon Project**: AI-powered VS Code extension that enforces custom, user-defined coding rules for React, Node.js, and TypeScript projects.

## 🎯 Project Overview

AI Rule Guard is an intelligent code reviewer that detects violations of team-defined coding standards in real-time. It uses **Google Gemini AI** to understand and enforce ANY custom rule you can describe in natural language.

### Key Features

✅ **Fully Dynamic Rules** – Define ANY rule with natural language descriptions  
✅ **Real-time Enforcement** – Detects violations as you code  
✅ **AI-Powered Analysis** – Semantic understanding via Google Gemini  
✅ **No Code Generation** – AI only reviews, never rewrites  
✅ **Multi-Language Support** – React, TypeScript, Node.js  
✅ **Folder Structure Rules** – Enforce file locations and organization  

---

## 🏗️ Architecture

```
┌─────────────────┐
│  VS Code Editor │
│   (Extension)   │
└────────┬────────┘
         │ File changes
         ▼
┌─────────────────┐
│  Rule Loader    │
│  (rules.json)   │
└────────┬────────┘
         │ Code + Rules
         ▼
┌─────────────────┐
│  Node.js Server │
│   (Express)     │
└────────┬────────┘
         │
    ┌────┴────┐
    ▼         ▼
┌────────┐ ┌──────────┐
│ Static │ │ Mistral  │
│ Checks │ │ AI API   │
└────────┘ └──────────┘
         │
         ▼
┌─────────────────┐
│   Violations    │
│  (Diagnostics)  │
└─────────────────┘
```

---

## 📦 Tech Stack

| Component | Technology |
|-----------|-----------|
| **Extension** | TypeScript, VS Code Extension API, Vite |
| **Server** | Node.js, Express, TypeScript |
| **AI** | Mistral AI API |
| **Communication** | REST API (axios) |

---

## 🌐 Web Interface

In addition to the VS Code extension, AI Rule Guard includes a **beautiful web interface** for testing and demonstrating the rule enforcement system.

### Features

- **Monaco Code Editor** - Same editor as VS Code
- **Live Rule Configuration** - Toggle and configure rules in real-time
- **Instant Feedback** - See violations as you analyze
- **Premium Dark UI** - Modern, gradient-based design
- **Responsive Layout** - Works on desktop and tablets

### Running the Web App

```bash
cd web
npm run dev
```

The web app will open at `http://localhost:5173`

### Using the Web Interface

1. **Write or paste code** in the Monaco editor
2. **Configure rules** in the right sidebar
3. **Click "Analyze Code"** to check for violations
4. **View results** in the violations panel below the editor

---

## 📁 Project Structure

```
ai-rule-guard/
│
├── extension/                 # VS Code Extension
│   ├── src/
│   │   ├── extension.ts      # Main extension logic
│   │   ├── ruleLoader.ts     # Loads rules.json
│   │   ├── diagnostics.ts    # Shows warnings in editor
│   ├── package.json
│   ├── tsconfig.json
│
├── server/                    # Node.js AI Server
│   ├── src/
│   │   ├── index.ts          # Express server setup
│   │   ├── routes/
│   │   │   └── analyze.ts    # /api/analyze endpoint
│   │   ├── ai/
│   │   │   └── mistral.ts    # Mistral AI integration
│   │   ├── rules/
│   │   │   └── validator.ts  # Static rule checks
│   ├── package.json
│   ├── tsconfig.json
│   ├── .env.example
│
├── web/                       # Web Interface (Vite + React)
│   ├── src/
│   │   ├── App.tsx           # Main app component
│   │   ├── components/
│   │   │   ├── CodeEditor.tsx      # Monaco editor
│   │   │   ├── RulesPanel.tsx      # Rules configuration
│   │   │   └── ViolationsPanel.tsx # Violations display
│   ├── package.json
│   ├── vite.config.ts
│
├── rules.json                 # User-defined rules
├── README.md
└── .gitignore
```

---

## 🚀 Setup Instructions

### Prerequisites

- **Node.js** 18+ and npm
- **VS Code** 1.85+
- **Mistral AI API Key** (get from [console.mistral.ai](https://console.mistral.ai/))

### 1️⃣ Clone/Setup Project

```bash
cd ai-rule-guard
```

### 2️⃣ Setup Server

```bash
cd server
npm install
```

Create `.env` file:

```bash
cp .env.example .env
```

Edit `.env` and add your Mistral API key:

```env
MISTRAL_API_KEY=your_actual_api_key_here
PORT=3000
```

### 3️⃣ Setup Extension

```bash
cd ../extension
npm install
npm run build
```

---

## 🎮 Running the Project

### Start the Server

```bash
cd server
npm run dev
```

You should see:

```
🚀 AI Rule Guard server running on http://localhost:3000
📋 Health check: http://localhost:3000/health
🔍 Analyze endpoint: http://localhost:3000/api/analyze
```

### Run the Extension

1. Open the `extension` folder in VS Code
2. Press **F5** to launch Extension Development Host
3. In the new window, open a TypeScript/React project
4. Create or edit a `.ts` or `.tsx` file
5. Save the file to trigger analysis

---

## 📋 Rules Configuration

Edit `rules.json` in your project root:

```json
{
  "no_any_type": true,
  "no_console_log": true,
  "function_name_case": "camelCase",
  "max_function_length": 40,
  "no_direct_fetch": true,
  "api_calls_must_use_hooks": true
}
```

### Available Rules

| Rule | Type | Description |
|------|------|-------------|
| `no_any_type` | boolean | Disallow `any` type in TypeScript |
| `no_console_log` | boolean | Disallow console.log in production |
| `function_name_case` | string | Enforce naming: `camelCase`, `PascalCase`, `snake_case` |
| `max_function_length` | number | Maximum lines per function |
| `no_direct_fetch` | boolean | Require fetch calls in hooks/services |
| `api_calls_must_use_hooks` | boolean | API calls must use custom hooks |

---

## 🔄 Demo Flow

1. **Developer writes code** in VS Code
2. **Extension detects change** (on save)
3. **Extension sends** code + rules to server
4. **Server runs**:
   - Static validation (regex-based)
   - Mistral AI semantic analysis
5. **AI responds** with violations only (no fixes)
6. **Extension displays** warnings in editor

### Example Violation

```typescript
// ❌ Violation: no_any_type
function processData(data: any) {
  console.log(data);  // ❌ Violation: no_console_log
}
```

**AI Response:**

```json
{
  "violations": [
    {
      "rule": "no_any_type",
      "line": 1,
      "message": "`any` type reduces type safety and should be avoided"
    },
    {
      "rule": "no_console_log",
      "line": 2,
      "message": "console.log() should not be used in production code"
    }
  ]
}
```

---

## 🧪 Testing

### Test Server Health

```bash
curl http://localhost:3000/health
```

### Test Analysis Endpoint

```bash
curl -X POST http://localhost:3000/api/analyze \
  -H "Content-Type: application/json" \
  -d '{
    "code": "const test: any = 123;",
    "fileType": "typescript",
    "rules": {"no_any_type": true}
  }'
```

### Test the Extension

1. Open Extension Development Host (F5)
2. Create a test TypeScript file with some violations:

```typescript
// Example with violations
const data: any = "test";
console.log(data);

function ProcessData() {
  // Function with PascalCase instead of camelCase
}
```

3. Save the file
4. Check for warnings in the Problems panel

---

## 🎤 Hackathon Pitch

> **"AI Rule Guard enforces team-defined coding rules in real-time using AI as an intelligent reviewer, not a code generator."**

### Why This Matters

- **Consistency**: Enforce team standards automatically
- **Learning**: Developers understand WHY rules exist
- **No Dependency**: AI reviews, doesn't replace developers
- **Customizable**: Every team defines their own rules

### AI as a Tool, Not a Solution

Unlike GitHub Copilot or ChatGPT that generate code, AI Rule Guard uses AI **strictly for analysis**:

✅ Detects semantic violations  
✅ Explains reasoning  
❌ Never generates code  
❌ Never auto-fixes  

---

## 🛠️ Development Commands

### Server

```bash
npm run dev      # Start development server
npm run build    # Compile TypeScript
npm start        # Run production build
```

### Extension

```bash
npm run build    # Compile TypeScript
npm run watch    # Watch mode for development
```

---

## 🔐 Environment Variables

| Variable | Required | Description |
|----------|----------|-------------|
| `MISTRAL_API_KEY` | Yes | Your Mistral AI API key |
| `PORT` | No | Server port (default: 3000) |

---

## 📝 VS Code Extension Commands

- **AI Rule Guard: Check Rules** – Manually trigger analysis
- **AI Rule Guard: Reload Rules** – Reload rules.json

---

## ⚙️ Extension Settings

| Setting | Default | Description |
|---------|---------|-------------|
| `aiRuleGuard.serverUrl` | `http://localhost:3000` | Server URL |
| `aiRuleGuard.rulesPath` | `./rules.json` | Path to rules file |
| `aiRuleGuard.enableAutoCheck` | `true` | Auto-check on save |

---

## 🐛 Troubleshooting

### Server won't start

- Check if port 3000 is available
- Verify `.env` file exists with valid API key

### Extension not working

- Ensure server is running
- Check VS Code Output panel (AI Rule Guard)
- Verify `rules.json` exists in workspace root

### No AI analysis

- Confirm `MISTRAL_API_KEY` is set in `.env`
- Check server logs for API errors

---

## 🚧 Future Enhancements

- [ ] Support for Python, Java, Go
- [ ] Custom rule definitions with regex
- [ ] Team rule sharing via cloud
- [ ] Performance metrics dashboard
- [ ] Integration with CI/CD pipelines

---

## 📄 License

MIT License - Hackathon Project 2024

---

## 👥 Team

Built with ❤️ for the hackathon

---

## 🔗 Resources

- [Mistral AI Documentation](https://docs.mistral.ai/)
- [VS Code Extension API](https://code.visualstudio.com/api)
- [Express.js](https://expressjs.com/)

---

**Ready to enforce your coding standards with AI? Let's go! 🚀**
