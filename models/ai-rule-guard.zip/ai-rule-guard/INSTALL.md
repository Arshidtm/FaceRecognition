# Installing AI Rule Guard Extension

## Method 1: Install from VSIX (Recommended)

### Step 1: Package the Extension

```bash
cd extension
npm install -g @vscode/vsce
vsce package
```

This creates a `.vsix` file (e.g., `ai-rule-guard-1.0.0.vsix`)

### Step 2: Install in VS Code

**Option A: Via Command Palette**
1. Open VS Code
2. Press `Ctrl+Shift+P` (or `Cmd+Shift+P` on Mac)
3. Type "Extensions: Install from VSIX"
4. Select the `.vsix` file from the `extension` folder

**Option B: Via Extensions Panel**
1. Open Extensions panel (`Ctrl+Shift+X`)
2. Click the `...` menu at the top
3. Select "Install from VSIX..."
4. Choose the `.vsix` file

### Step 3: Reload VS Code

Click "Reload" when prompted, or restart VS Code

---

## Method 2: Development Mode (For Testing)

### Step 1: Open Extension Folder

1. Open VS Code
2. File → Open Folder
3. Select `e:\sagar_syncrup\ai-rule-guard\extension`

### Step 2: Launch Extension Development Host

1. Press **F5** (or Run → Start Debugging)
2. A new VS Code window opens (Extension Development Host)
3. This window has the extension loaded

### Step 3: Open Your Project

In the Extension Development Host window:
1. File → Open Folder
2. Select your project folder
3. The extension is now active in this project!

---

## Setting Up Your Project

### 1. Create rules.json

In your project root, create `rules.json`:

```json
{
  "rules": [
    {
      "id": "hooks-folder-structure",
      "name": "Hooks Folder Structure",
      "description": "All custom hooks must be created inside the hooks/app folder",
      "severity": "warning",
      "filePattern": "**/use*.{ts,tsx}"
    },
    {
      "id": "no-any-type",
      "name": "No Any Type",
      "description": "Using 'any' type reduces type safety and should be avoided",
      "severity": "warning"
    },
    {
      "id": "no-console-log",
      "name": "No Console Log",
      "description": "console.log() should not be used in production code",
      "severity": "warning"
    }
  ]
}
```

### 2. Ensure Server is Running

```bash
cd e:\sagar_syncrup\ai-rule-guard\server
npm start
```

You should see:
```
🚀 AI Rule Guard server running on http://localhost:3000
```

### 3. Configure Extension (Optional)

In VS Code settings (`Ctrl+,`), search for "AI Rule Guard":

- **Server URL**: `http://localhost:3000` (default)
- **Rules Path**: `./rules.json` (default)
- **Enable Auto Check**: `true` (default)

---

## Testing the Extension

### Quick Test

1. **Create a test file** in your project:

```typescript
// test.ts
const data: any = "test";  // Violation: no-any-type
console.log(data);         // Violation: no-console-log
```

2. **Save the file** (`Ctrl+S`)

3. **See the magic!**
   - Warning popup appears
   - Click "View Details"
   - Violation panel opens
   - Click violations to jump to code

### Test Folder Structure Rule

1. **Create a hook outside hooks/app**:

```typescript
// src/useMyHook.ts (WRONG LOCATION)
export function useMyHook() {
  return {};
}
```

2. **Save and see violation** about folder structure

3. **Move to correct location**:
   - Create `hooks/app/useMyHook.ts`
   - Save and violation disappears ✓

---

## Troubleshooting

### Extension Not Working?

1. **Check server is running**:
   ```bash
   curl http://localhost:3000/health
   ```

2. **Check Output panel**:
   - View → Output
   - Select "AI Rule Guard" from dropdown
   - Look for error messages

3. **Check rules.json exists**:
   - Must be in project root
   - Must be valid JSON

### No Violations Detected?

1. **Reload rules**:
   - `Ctrl+Shift+P` → "AI Rule Guard: Reload Rules"

2. **Manually trigger check**:
   - `Ctrl+Shift+P` → "AI Rule Guard: Check Rules"

3. **Check file type**:
   - Extension only works on `.ts`, `.tsx`, `.js`, `.jsx` files

---

## Uninstalling

### If installed via VSIX:
1. Extensions panel (`Ctrl+Shift+X`)
2. Find "AI Rule Guard"
3. Click gear icon → Uninstall

### If in development mode:
- Just close the Extension Development Host window

---

## Next Steps

- Define your team's custom rules in `rules.json`
- Share `rules.json` with your team via Git
- Enjoy consistent code quality! 🎉
