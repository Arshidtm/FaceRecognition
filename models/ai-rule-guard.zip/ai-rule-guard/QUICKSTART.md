# Quick Start Guide

## 🚀 Running the Project

### 1. Start the Server

```bash
cd server
npm run dev
```

**Expected Output:**
```
🚀 AI Rule Guard server running on http://localhost:3000
📋 Health check: http://localhost:3000/health
🔍 Analyze endpoint: http://localhost:3000/api/analyze
```

### 2. Run the Extension

1. Open VS Code
2. Go to `File > Open Folder` and select the `extension` folder
3. Press **F5** to launch Extension Development Host
4. In the new VS Code window, open the `ai-rule-guard` project folder
5. Open `test-example.ts` or create a new TypeScript file
6. Save the file to trigger analysis

### 3. Test the Extension

Open the test files provided:
- `test-example.ts` - TypeScript violations
- `test-react.tsx` - React-specific violations

Save any file to see violations appear in the Problems panel.

## 🧪 Manual Testing

### Test Server Health

```bash
curl http://localhost:3000/health
```

### Test Analysis Endpoint

```bash
curl -X POST http://localhost:3000/api/analyze \
  -H "Content-Type: application/json" \
  -d "{\"code\":\"const test: any = 123;\",\"fileType\":\"typescript\",\"rules\":{\"no_any_type\":true}}"
```

## 📝 Customizing Rules

Edit `rules.json`:

```json
{
  "no_any_type": true,
  "no_console_log": true,
  "function_name_case": "camelCase",
  "max_function_length": 40,
  "no_direct_fetch": true,
  "api_calls_must_use_hooks": true
}
```

Then run: **AI Rule Guard: Reload Rules** from the command palette.

## 🔑 Setting Up Mistral AI (Optional)

1. Get API key from [console.mistral.ai](https://console.mistral.ai/)
2. Create `server/.env`:
   ```
   MISTRAL_API_KEY=your_key_here
   PORT=3000
   ```
3. Restart the server

**Note:** The extension works without Mistral AI using static analysis. AI provides semantic understanding.

## 🐛 Troubleshooting

**Extension not showing violations:**
- Check if server is running on port 3000
- Check VS Code Output panel (View > Output > AI Rule Guard)
- Verify `rules.json` exists in workspace root

**Server errors:**
- Check if port 3000 is available
- Verify all dependencies are installed
- Check server console for error messages

## 📦 Building for Production

### Build Server
```bash
cd server
npm run build
npm start
```

### Package Extension
```bash
cd extension
npm install -g vsce
vsce package
```

This creates a `.vsix` file you can install in VS Code.
