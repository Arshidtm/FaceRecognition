const code = `
import React, { Fragment } from "react";

const App: React.FC = () => {
  console.log("nnnnnnnnnnn");
  const data = <div style={{ display: "flex" }}></div>;
  return <div>App</div>;
};
export default App;
`;

const rules = {
    "rules": [
        {
            "id": "no-console-log",
            "name": "No Console Log",
            "description": "console.log() statements should not be used in production code.",
            "severity": "warning",
            "enabled": true
        },
        {
            "id": "no-inline-styles",
            "name": "No Inline Styles",
            "description": "Detect ANY usage of the 'style' prop in JSX elements (e.g., style={{ ... }}). Inline styles are strictly forbidden.",
            "severity": "warning",
            "enabled": true
        }
    ]
};

const fs = require('fs');

async function test() {
    const log = (msg) => {
        console.log(msg);
        fs.appendFileSync('verify_result.txt', msg + '\n');
    };

    try {
        fs.writeFileSync('verify_result.txt', 'Starting test...\n');
        log('Sending request to AI Rule Guard Server...');

        // Node.js 18+ has native fetch
        const response = await fetch('http://localhost:3000/api/analyze', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                code: code,
                fileType: 'typescriptreact', // React file type
                rules: rules
            })
        });

        log('Response status: ' + response.status);

        const data = await response.json();
        log('Violations found: ' + JSON.stringify(data.violations, null, 2));

    } catch (error) {
        log('Error: ' + error.message);
    }
}

test();
