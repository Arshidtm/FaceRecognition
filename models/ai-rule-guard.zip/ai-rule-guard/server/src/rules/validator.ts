interface Violation {
    rule: string;
    line: number;
    message: string;
    severity?: 'error' | 'warning' | 'info';
}

// Static validation has been removed - all validation is now AI-driven
// See gemini.ts for AI-based rule interpretation
