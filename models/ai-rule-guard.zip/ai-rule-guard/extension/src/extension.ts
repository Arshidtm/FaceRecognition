import * as vscode from 'vscode';
import { RuleLoader } from './ruleLoader';
import { DiagnosticsManager } from './diagnostics';
import { ViolationPanel } from './violationPanel';
import axios from 'axios';

let diagnosticsManager: DiagnosticsManager;
let ruleLoader: RuleLoader;

export function activate(context: vscode.ExtensionContext) {
    console.log('AI Rule Guard extension activated');

    // Initialize managers
    diagnosticsManager = new DiagnosticsManager();
    ruleLoader = new RuleLoader();

    // Load rules on activation
    ruleLoader.loadRules();

    // Register commands
    const checkRulesCommand = vscode.commands.registerCommand(
        'ai-rule-guard.checkRules',
        async () => {
            const editor = vscode.window.activeTextEditor;
            if (editor) {
                await checkDocument(editor.document);
            }
        }
    );

    const reloadRulesCommand = vscode.commands.registerCommand(
        'ai-rule-guard.reloadRules',
        () => {
            ruleLoader.loadRules();
            vscode.window.showInformationMessage('AI Rule Guard: Rules reloaded');
        }
    );

    // Auto-check on save
    const onSaveDisposable = vscode.workspace.onDidSaveTextDocument(
        async (document) => {
            const config = vscode.workspace.getConfiguration('aiRuleGuard');
            const enableAutoCheck = config.get<boolean>('enableAutoCheck', true);

            if (enableAutoCheck && isSupportedLanguage(document.languageId)) {
                await checkDocument(document);
            }
        }
    );

    // Auto-check on open
    const onOpenDisposable = vscode.workspace.onDidOpenTextDocument(
        async (document) => {
            if (isSupportedLanguage(document.languageId)) {
                await checkDocument(document);
            }
        }
    );

    // Watch for changes in rules.json
    const rulesWatcher = vscode.workspace.createFileSystemWatcher('**/rules.json');
    rulesWatcher.onDidChange(() => {
        console.log('rules.json changed, reloading rules...');
        ruleLoader.loadRules();
        vscode.window.showInformationMessage('AI Rule Guard: Rules updated');
    });
    rulesWatcher.onDidCreate(() => {
        console.log('rules.json created, loading rules...');
        ruleLoader.loadRules();
    });
    rulesWatcher.onDidDelete(() => {
        console.log('rules.json deleted');
        ruleLoader.loadRules();
    });

    context.subscriptions.push(
        checkRulesCommand,
        reloadRulesCommand,
        onSaveDisposable,
        onOpenDisposable,
        diagnosticsManager.diagnosticCollection,
        rulesWatcher
    );
}

async function checkDocument(document: vscode.TextDocument): Promise<void> {
    if (!isSupportedLanguage(document.languageId)) {
        return;
    }

    const code = document.getText();
    const rules = ruleLoader.getRules();

    if (!rules) {
        vscode.window.showWarningMessage(
            'AI Rule Guard: No rules loaded. Check rules.json path.'
        );
        return;
    }

    try {
        const config = vscode.workspace.getConfiguration('aiRuleGuard');
        const serverUrl = config.get<string>('serverUrl', 'http://localhost:3000');

        // Determine file type
        const fileType = getFileType(document.languageId);
        
        // Get workspace-relative file path
        const workspaceFolders = vscode.workspace.workspaceFolders;
        let relativePath = document.fileName;
        if (workspaceFolders && workspaceFolders.length > 0) {
            relativePath = vscode.workspace.asRelativePath(document.fileName);
        }

        // Show progress
        await vscode.window.withProgress(
            {
                location: vscode.ProgressLocation.Notification,
                title: 'AI Rule Guard: Analyzing code...',
                cancellable: false,
            },
            async () => {
                const response = await axios.post(`${serverUrl}/api/analyze`, {
                    code,
                    fileType,
                    rules,
                    filePath: relativePath,
                });

                const violations = response.data.violations || [];
                diagnosticsManager.updateDiagnostics(document, violations);

                if (violations.length > 0) {
                    // Show warning with View Details button
                    const action = await vscode.window.showWarningMessage(
                        `AI Rule Guard: Found ${violations.length} rule violation${violations.length !== 1 ? 's' : ''}`,
                        'View Details',
                        'Dismiss'
                    );
                    
                    if (action === 'View Details') {
                        ViolationPanel.show(violations, document);
                    }
                } else {
                    vscode.window.showInformationMessage(
                        'AI Rule Guard: No violations found ✓'
                    );
                }
            }
        );
    } catch (error: any) {
        const errorMessage = error.response?.data?.error || error.message;
        vscode.window.showErrorMessage(
            `AI Rule Guard: ${errorMessage}`
        );
        console.error('AI Rule Guard error:', error);
    }
}

function isSupportedLanguage(languageId: string): boolean {
    return [
        'typescript',
        'typescriptreact',
        'javascript',
        'javascriptreact',
    ].includes(languageId);
}

function getFileType(languageId: string): string {
    switch (languageId) {
        case 'typescriptreact':
            return 'react';
        case 'typescript':
            return 'typescript';
        case 'javascriptreact':
            return 'react';
        case 'javascript':
            return 'node';
        default:
            return 'typescript';
    }
}

export function deactivate() {
    console.log('AI Rule Guard extension deactivated');
}
