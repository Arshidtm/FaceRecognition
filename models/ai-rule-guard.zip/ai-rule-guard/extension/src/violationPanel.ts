import * as vscode from 'vscode';

export interface Violation {
    rule: string;
    line: number;
    message: string;
    severity?: 'error' | 'warning' | 'info';
}

export class ViolationPanel {
    private static currentPanel: ViolationPanel | undefined;
    private readonly panel: vscode.WebviewPanel;
    private violations: Violation[] = [];
    private disposables: vscode.Disposable[] = [];

    private constructor(panel: vscode.WebviewPanel) {
        this.panel = panel;
        this.panel.onDidDispose(() => this.dispose(), null, this.disposables);
    }

    public static show(violations: Violation[], document: vscode.TextDocument): void {
        const column = vscode.window.activeTextEditor
            ? vscode.window.activeTextEditor.viewColumn
            : undefined;

        // If we already have a panel, show it
        if (ViolationPanel.currentPanel) {
            ViolationPanel.currentPanel.panel.reveal(column);
            ViolationPanel.currentPanel.update(violations, document);
            return;
        }

        // Otherwise, create a new panel
        const panel = vscode.window.createWebviewPanel(
            'aiRuleGuardViolations',
            'AI Rule Guard - Violations',
            column || vscode.ViewColumn.Two,
            {
                enableScripts: true,
                retainContextWhenHidden: true,
            }
        );

        ViolationPanel.currentPanel = new ViolationPanel(panel);
        ViolationPanel.currentPanel.update(violations, document);
    }

    private update(violations: Violation[], document: vscode.TextDocument): void {
        this.violations = violations;
        this.panel.title = `AI Rule Guard - ${violations.length} Violation${violations.length !== 1 ? 's' : ''}`;
        this.panel.webview.html = this.getHtmlContent(violations, document);

        // Handle messages from the webview
        this.panel.webview.onDidReceiveMessage(
            (message) => {
                switch (message.command) {
                    case 'jumpToLine':
                        this.jumpToLine(document, message.line);
                        break;
                }
            },
            null,
            this.disposables
        );
    }

    private jumpToLine(document: vscode.TextDocument, line: number): void {
        vscode.window.showTextDocument(document).then((editor) => {
            const lineNumber = Math.max(0, line - 1);
            const position = new vscode.Position(lineNumber, 0);
            editor.selection = new vscode.Selection(position, position);
            editor.revealRange(
                new vscode.Range(position, position),
                vscode.TextEditorRevealType.InCenter
            );
        });
    }

    private getHtmlContent(violations: Violation[], document: vscode.TextDocument): string {
        const fileName = document.fileName.split(/[\\/]/).pop() || 'Unknown File';
        const violationsByRule = this.groupViolationsByRule(violations);

        return `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AI Rule Guard Violations</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: var(--vscode-font-family);
            color: var(--vscode-foreground);
            background: var(--vscode-editor-background);
            padding: 20px;
            line-height: 1.6;
        }
        
        .header {
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 2px solid var(--vscode-panel-border);
        }
        
        .header h1 {
            font-size: 24px;
            margin-bottom: 10px;
            color: var(--vscode-errorForeground);
        }
        
        .file-info {
            font-size: 14px;
            color: var(--vscode-descriptionForeground);
        }
        
        .summary {
            display: flex;
            gap: 20px;
            margin-top: 15px;
        }
        
        .summary-item {
            padding: 10px 15px;
            background: var(--vscode-badge-background);
            color: var(--vscode-badge-foreground);
            border-radius: 4px;
            font-size: 13px;
        }
        
        .rule-group {
            margin-bottom: 30px;
            background: var(--vscode-editor-inactiveSelectionBackground);
            border-radius: 8px;
            overflow: hidden;
        }
        
        .rule-header {
            padding: 15px 20px;
            background: var(--vscode-sideBar-background);
            border-left: 4px solid var(--vscode-errorForeground);
            cursor: pointer;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .rule-header:hover {
            background: var(--vscode-list-hoverBackground);
        }
        
        .rule-name {
            font-weight: 600;
            font-size: 16px;
        }
        
        .rule-count {
            background: var(--vscode-errorForeground);
            color: white;
            padding: 4px 10px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 600;
        }
        
        .violations-list {
            padding: 0;
        }
        
        .violation-item {
            padding: 15px 20px;
            border-bottom: 1px solid var(--vscode-panel-border);
            cursor: pointer;
            transition: background 0.2s;
        }
        
        .violation-item:hover {
            background: var(--vscode-list-hoverBackground);
        }
        
        .violation-item:last-child {
            border-bottom: none;
        }
        
        .violation-line {
            display: inline-block;
            background: var(--vscode-textCodeBlock-background);
            padding: 2px 8px;
            border-radius: 3px;
            font-family: var(--vscode-editor-font-family);
            font-size: 12px;
            margin-right: 10px;
            color: var(--vscode-textLink-foreground);
        }
        
        .violation-message {
            margin-top: 8px;
            color: var(--vscode-foreground);
        }
        
        .severity-error {
            border-left-color: var(--vscode-errorForeground);
        }
        
        .severity-warning {
            border-left-color: var(--vscode-editorWarning-foreground);
        }
        
        .severity-info {
            border-left-color: var(--vscode-editorInfo-foreground);
        }
        
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: var(--vscode-descriptionForeground);
        }
        
        .empty-state h2 {
            font-size: 20px;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>🛡️ AI Rule Guard - Violations Detected</h1>
        <div class="file-info">File: <strong>${fileName}</strong></div>
        <div class="summary">
            <div class="summary-item">Total Violations: ${violations.length}</div>
            <div class="summary-item">Rules Violated: ${Object.keys(violationsByRule).length}</div>
        </div>
    </div>
    
    ${violations.length === 0 ? `
        <div class="empty-state">
            <h2>✅ No Violations Found</h2>
            <p>Your code follows all defined rules!</p>
        </div>
    ` : Object.entries(violationsByRule).map(([ruleName, ruleViolations]) => `
        <div class="rule-group">
            <div class="rule-header severity-${ruleViolations[0].severity || 'warning'}">
                <div class="rule-name">${this.formatRuleName(ruleName)}</div>
                <div class="rule-count">${ruleViolations.length}</div>
            </div>
            <div class="violations-list">
                ${ruleViolations.map(v => `
                    <div class="violation-item" onclick="jumpToLine(${v.line})">
                        <div>
                            <span class="violation-line">Line ${v.line}</span>
                        </div>
                        <div class="violation-message">${v.message}</div>
                    </div>
                `).join('')}
            </div>
        </div>
    `).join('')}
    
    <script>
        const vscode = acquireVsCodeApi();
        
        function jumpToLine(line) {
            vscode.postMessage({
                command: 'jumpToLine',
                line: line
            });
        }
    </script>
</body>
</html>`;
    }

    private groupViolationsByRule(violations: Violation[]): Record<string, Violation[]> {
        const grouped: Record<string, Violation[]> = {};
        
        for (const violation of violations) {
            if (!grouped[violation.rule]) {
                grouped[violation.rule] = [];
            }
            grouped[violation.rule].push(violation);
        }
        
        return grouped;
    }

    private formatRuleName(ruleName: string): string {
        // Convert kebab-case or snake_case to Title Case
        return ruleName
            .split(/[-_]/)
            .map(word => word.charAt(0).toUpperCase() + word.slice(1))
            .join(' ');
    }

    public dispose(): void {
        ViolationPanel.currentPanel = undefined;

        this.panel.dispose();

        while (this.disposables.length) {
            const disposable = this.disposables.pop();
            if (disposable) {
                disposable.dispose();
            }
        }
    }
}
