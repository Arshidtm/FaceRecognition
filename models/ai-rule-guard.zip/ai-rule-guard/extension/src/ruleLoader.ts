import * as vscode from 'vscode';
import * as fs from 'fs';
import * as path from 'path';

export interface Rule {
    id: string;
    name: string;
    description: string;
    severity?: 'error' | 'warning' | 'info';
    enabled?: boolean;
    filePattern?: string;
}

export interface RulesConfig {
    rules: Rule[];
}

export class RuleLoader {
    private rules: RulesConfig | null = null;

    public loadRules(): void {
        try {
            const config = vscode.workspace.getConfiguration('aiRuleGuard');
            const rulesPath = config.get<string>('rulesPath', './rules.json');

            // Try to find rules.json in workspace
            const workspaceFolders = vscode.workspace.workspaceFolders;
            if (!workspaceFolders || workspaceFolders.length === 0) {
                console.warn('No workspace folder found');
                return;
            }

            const workspaceRoot = workspaceFolders[0].uri.fsPath;
            const fullRulesPath = path.isAbsolute(rulesPath)
                ? rulesPath
                : path.join(workspaceRoot, rulesPath);

            if (!fs.existsSync(fullRulesPath)) {
                console.warn(`Rules file not found at: ${fullRulesPath}`);
                // Create default rules file
                this.createDefaultRulesFile(fullRulesPath);
                return;
            }

            const rulesContent = fs.readFileSync(fullRulesPath, 'utf-8');
            const parsedRules = JSON.parse(rulesContent);
            
            // Only accept new format
            if (this.isValidFormat(parsedRules)) {
                this.rules = parsedRules as RulesConfig;
                console.log('Rules loaded successfully:', this.rules);
            } else {
                vscode.window.showErrorMessage(
                    'AI Rule Guard: Invalid rules format. Please use the array format with rule descriptions.'
                );
            }
        } catch (error) {
            console.error('Error loading rules:', error);
            vscode.window.showErrorMessage(
                `AI Rule Guard: Failed to load rules - ${error}`
            );
        }
    }

    public getRules(): RulesConfig | null {
        return this.rules;
    }

    private isValidFormat(rules: any): rules is RulesConfig {
        return rules && Array.isArray(rules.rules);
    }

    private createDefaultRulesFile(filePath: string): void {
        const defaultRules: RulesConfig = {
            rules: [
                {
                    id: "hooks-folder-structure",
                    name: "Hooks Folder Structure",
                    description: "All custom hooks must be created inside the 'hooks/app' folder. Hook files should follow the naming pattern 'use*.ts' or 'use*.tsx'. If a hook file is found outside this folder, it violates this rule.",
                    severity: "error",
                    enabled: true,
                    filePattern: "**/use*.{ts,tsx}"
                }
            ]
        };

        try {
            fs.writeFileSync(filePath, JSON.stringify(defaultRules, null, 2));
            this.rules = defaultRules;
            vscode.window.showInformationMessage(
                `AI Rule Guard: Created default rules.json at ${filePath}`
            );
        } catch (error) {
            console.error('Error creating default rules file:', error);
        }
    }
}
