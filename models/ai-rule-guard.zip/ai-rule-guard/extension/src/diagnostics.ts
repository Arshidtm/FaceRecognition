import * as vscode from 'vscode';

export interface Violation {
    rule: string;
    line: number;
    message: string;
    severity?: 'error' | 'warning' | 'info';
}

export class DiagnosticsManager {
    public diagnosticCollection: vscode.DiagnosticCollection;

    constructor() {
        this.diagnosticCollection = vscode.languages.createDiagnosticCollection(
            'ai-rule-guard'
        );
    }

    public updateDiagnostics(
        document: vscode.TextDocument,
        violations: Violation[]
    ): void {
        const diagnostics: vscode.Diagnostic[] = violations.map((violation) => {
            // Convert 1-based line number to 0-based
            const lineNumber = Math.max(0, violation.line - 1);
            const line = document.lineAt(
                Math.min(lineNumber, document.lineCount - 1)
            );

            const range = new vscode.Range(
                lineNumber,
                0,
                lineNumber,
                line.text.length
            );

            const severity = this.getSeverity(violation.severity);
            const message = `[${violation.rule}] ${violation.message}`;

            const diagnostic = new vscode.Diagnostic(range, message, severity);
            diagnostic.source = 'AI Rule Guard';
            diagnostic.code = violation.rule;

            return diagnostic;
        });

        this.diagnosticCollection.set(document.uri, diagnostics);
    }

    public clearDiagnostics(document: vscode.TextDocument): void {
        this.diagnosticCollection.delete(document.uri);
    }

    private getSeverity(
        severity?: 'error' | 'warning' | 'info'
    ): vscode.DiagnosticSeverity {
        switch (severity) {
            case 'error':
                return vscode.DiagnosticSeverity.Error;
            case 'info':
                return vscode.DiagnosticSeverity.Information;
            case 'warning':
            default:
                return vscode.DiagnosticSeverity.Warning;
        }
    }
}
